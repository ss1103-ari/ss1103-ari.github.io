#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""午餐雷达幂等锁：同一天同一时段只允许推送一次。

幂等键 = <date>-<slot>，锁文件落在 ~/.lunch-radar/ 下，任务重跑不会连发。

用法：
    python3 scripts/once_guard.py --slot 12:15            # 抢锁：first_run=true 才发送
    python3 scripts/once_guard.py --slot 12:15 --check    # 只查询，不写锁
    python3 scripts/once_guard.py --slot 12:15 --release  # 发送失败时释放，允许重试
退出码：0 = 可以发送（或查询成功），3 = 今天该时段已发送过。
"""
import argparse
import json
import os
import sys
from datetime import date, datetime

STATE_DIR = os.path.join(os.path.expanduser("~"), ".lunch-radar")


def lock_path(day, slot):
    return os.path.join(STATE_DIR, f"{day}-{slot.replace(':', '')}.lock")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slot", required=True, help="12:15 或 12:30")
    ap.add_argument("--date", default=date.today().isoformat())
    ap.add_argument("--check", action="store_true", help="只查询状态")
    ap.add_argument("--release", action="store_true", help="释放锁，允许重试")
    a = ap.parse_args()

    os.makedirs(STATE_DIR, exist_ok=True)
    path = lock_path(a.date, a.slot)
    key = f"{a.date}-{a.slot}"

    if a.release:
        existed = os.path.exists(path)
        if existed:
            os.remove(path)
        print(json.dumps({"key": key, "released": existed, "first_run": True},
                         ensure_ascii=False))
        return 0

    if os.path.exists(path):
        with open(path) as f:
            sent_at = f.read().strip()
        print(json.dumps({"key": key, "first_run": False, "sent_at": sent_at,
                          "action": "skip"}, ensure_ascii=False))
        return 3

    if not a.check:
        with open(path, "w") as f:
            f.write(datetime.now().isoformat(timespec="seconds"))
    print(json.dumps({"key": key, "first_run": True, "action": "send"},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
