#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把「文字简报 + 菜单原图」合成为 **一条** 飞书 post 消息发送。

用户明确要求：图片不要分开发多条，必须和文字在同一条消息里。
做法：先用 `lark-cli im images create` 逐张上传拿 img_key，
再拼一个 post message（content JSON），一次 `+messages-send --msg-type post` 发出。

用法：
    python3 scripts/send_lunch_message.py \
        --user-id "$OPEN_ID" \
        --text-file /tmp/lr_text.txt \
        --images outputs/lunch-radar/img/32F_自选餐线_1.png,outputs/lunch-radar/img/32F_猪角.png \
        [--images-from /tmp/imgs.json] [--max-images 12] [--dry-run]

输出 JSON：{"status": "sent"|"failed"|"partial", "message_id":..., "image_count":N,
            "uploaded":[...], "upload_failed":[...], "error":...}
退出码：0 成功（含 partial），1 失败。
"""
import argparse
import json
import os
import re
import subprocess
import sys

MAX_IMAGES = 12


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr


def rel(path):
    """lark-cli 只接受 cwd 相对路径（拒绝绝对路径和 ..）。"""
    return os.path.relpath(os.path.abspath(path), os.getcwd())


def upload(path):
    code, out, err = run([
        "lark-cli", "im", "images", "create",
        "--data", json.dumps({"image_type": "message"}),
        "--file", "image=" + rel(path),
        "--as", "bot",
        "--format", "json",
    ])
    if code != 0:
        return None, (err or out).strip()[:300]
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        return None, out.strip()[:300]
    key = data.get("image_key") or (data.get("data") or {}).get("image_key")
    if not key:
        return None, out.strip()[:300]
    return key, None


def collect_images(args):
    paths = []
    if args.images:
        paths += [p.strip() for p in args.images.split(",") if p.strip()]
    if args.images_from:
        with open(args.images_from, encoding="utf-8") as f:
            data = json.load(f)
        for item in data.get("images", data if isinstance(data, list) else []):
            if isinstance(item, str):
                paths.append(item)
            elif isinstance(item, dict):
                # 发原图，不用 ocr_path（那是压缩给 OCR 用的）
                p = item.get("path") or item.get("image_path")
                if p:
                    paths.append(p)
    seen, out = set(), []
    for p in paths:
        if p in seen or not os.path.isfile(p):
            continue
        seen.add(p)
        out.append(p)
    return out[: args.max_images]


IMG_MARK = re.compile(r"^\s*\[\[IMG:(?P<path>[^\]]+)\]\]\s*$")


def build_post(text, image_keys):
    """post 结构：正文段落在前，图片段落跟在后面，全部在同一条消息里。

    飞书 post 的每个 content 元素是「一行」；图片必须单独成行。
    """
    lines = [[{"tag": "text", "text": line}] for line in text.split("\n")]
    for key in image_keys:
        lines.append([{"tag": "img", "image_key": key}])
    return {"zh_cn": {"content": lines}}


def build_interleaved_post(text, uploader):
    """图文交错：正文里的 `[[IMG:相对路径]]` 独占一行的标记，会被替换成该图片行。

    用户明确要求「楼层文字描述后紧跟该楼层的图」，禁止把图全堆在末尾。
    uploader(path) -> (image_key, error)。
    返回 (post_content, uploaded, failed)。
    """
    lines, uploaded, failed = [], [], []
    cache = {}
    for line in text.split("\n"):
        m = IMG_MARK.match(line)
        if not m:
            lines.append([{"tag": "text", "text": line}])
            continue
        path = m.group("path").strip()
        if path in cache:
            lines.append([{"tag": "img", "image_key": cache[path]}])
            continue
        if not os.path.isfile(path):
            failed.append({"path": path, "error": "file not found"})
            continue
        key, err = uploader(path)
        if key:
            cache[path] = key
            uploaded.append(path)
            lines.append([{"tag": "img", "image_key": key}])
        else:
            failed.append({"path": path, "error": err})
    return {"zh_cn": {"content": lines}}, uploaded, failed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--user-id", help="bot 域 open_id（ou_xxx）")
    ap.add_argument("--chat-id")
    ap.add_argument("--text-file", required=True)
    ap.add_argument("--images", default="")
    ap.add_argument("--images-from", default="")
    ap.add_argument("--max-images", type=int, default=MAX_IMAGES)
    ap.add_argument("--idempotency-key", default="")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if not args.user_id and not args.chat_id:
        print(json.dumps({"status": "failed", "error": "need --user-id or --chat-id"}, ensure_ascii=False))
        return 1

    with open(args.text_file, encoding="utf-8") as f:
        text = f.read().rstrip("\n")

    if any(IMG_MARK.match(l) for l in text.split("\n")):
        # 图文交错模式：正文自带 [[IMG:path]] 标记，图片插在对应楼层文字后面
        post, uploaded, failed = build_interleaved_post(text, upload)
        keys = uploaded
    else:
        paths = collect_images(args)
        keys, uploaded, failed = [], [], []
        for p in paths:
            key, err = upload(p)
            if key:
                keys.append(key)
                uploaded.append(p)
            else:
                failed.append({"path": p, "error": err})
        post = build_post(text, keys)

    content = json.dumps(post, ensure_ascii=False)
    cmd = ["lark-cli", "im", "+messages-send", "--msg-type", "post",
           "--content", content, "--as", "bot", "--format", "json"]
    if args.user_id:
        cmd += ["--user-id", args.user_id]
    else:
        cmd += ["--chat-id", args.chat_id]
    if args.idempotency_key:
        cmd += ["--idempotency-key", args.idempotency_key]
    if args.dry_run:
        cmd.append("--dry-run")

    code, out, err = run(cmd)
    if code != 0:
        print(json.dumps({"status": "failed", "image_count": len(keys),
                          "upload_failed": failed,
                          "error": (err or out).strip()[:500]}, ensure_ascii=False))
        return 1

    try:
        resp = json.loads(out)
    except json.JSONDecodeError:
        resp = {"raw": out.strip()[:500]}
    print(json.dumps({
        "status": "partial" if failed else "sent",
        "message_id": resp.get("message_id") or (resp.get("data") or {}).get("message_id"),
        "image_count": len(keys),
        "uploaded": uploaded,
        "upload_failed": failed,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
