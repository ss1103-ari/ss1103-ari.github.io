#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""拉取「深圳湾餐饮话题群③」当天的午餐预告卡片，按 P0-P3 规则过滤，输出结构化 JSON + 可直接发送的文本。

用法：
    python3 scripts/fetch_lunch_preview.py                       # today
    python3 scripts/fetch_lunch_preview.py --date 2026-08-14
    python3 scripts/fetch_lunch_preview.py --chat-id oc_xxx
    python3 scripts/fetch_lunch_preview.py --slot 12:30          # 只输出 12:30 提醒话术

输出 JSON 字段：
    status: ok | no_preview | degraded | chat_not_found | error
    chat_id, date, cards[], sections[], likes_hits[], lobster_hits[], message_text, links[]
    queue_notices[]  12:00 后各楼层「开餐排队情况」卡片（多为图片，只有楼层+档口名可解析）
    soldout_notices[] 12:30 后「售罄 / 中断提示」卡片（纯文本，可解析菜名）

为什么抓 11:40-12:10 而不是「最新一条」：12:00 后各楼层排队通知会把菜单卡片刷上去，
用户 12 点多才去吃饭时手动往上翻很痛苦，本脚本就是替她把那个时间窗的菜单捞回来。
"""
import argparse
import json
import os
import re
import subprocess
import sys
from datetime import date as _date, datetime

CHAT_NAME = "深圳湾餐饮话题群③"
CHAT_ID_DEFAULT = "oc_3abf3bed1e09c8b82b2a7946ac79f24b"

# 爱吃清单：规范名 -> 命中别名
LIKES = {
    "美蛙鱼": ["美蛙鱼", "美蛙", "牛蛙", "田鸡"],
    "小龙虾": ["小龙虾", "龙虾"],
    "酸菜鱼": ["酸菜鱼", "酸汤鱼"],
    "肥肠": ["肥肠", "猪大肠", "九转大肠"],
    "冬阴功": ["冬阴功", "冬荫功", "冬阳功"],
    "椰子鸡": ["椰子鸡", "椰汁鸡"],
}
LOBSTER = ["小龙虾", "龙虾"]

WEEKDAY_CN = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

# 段落标题行：以 ✨ / ❣️ / ### 起头，或含 「」/【】 档口名
HEADER_RE = re.compile(r"^(?:\*+)?\s*(?:[✨❣💕🔸▪]|###)|[「【][^」】]{2,20}[」】]")
FLOOR_RE = re.compile(r"(B7|A7|\d{1,2})\s*(?:F|楼)?\s*(?=[-—\s／/、（(【「]|$)")
DISH_LINE_RE = re.compile(r"[：:]")
NOISE_WORDS = (
    "温馨提示", "注意事项", "微波炉", "许愿", "路线指引", "指引", "点击查看", "点餐",
    "供餐日期", "用餐时间", "用餐区域", "取餐时间", "取餐地点", "截单", "食品安全",
    "更多", "餐饮指南", "服务指南", "不建议", "已关闭",
)
# 这些段落不是菜单，直接丢弃
SKIP_HEADERS = ("路线指引", "指引", "温馨提示", "许愿", "注意事项", "餐饮指南", "服务指南")
META_RE = re.compile(r"^[📅⏰📍⚠]")
# 图片行两种写法：`Image(img_key:img_xxx)` / `2 image(s)(keys:img_a,img_b)`
IMG_KEY_RE = re.compile(r"(?:img_key:|keys:)([^)]+)")


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    out = p.stdout.strip()
    if "{" in out:
        out = out[out.index("{"):]
    try:
        return json.loads(out)
    except Exception:
        return {"ok": False, "error": {"message": (p.stderr or p.stdout)[:500]}}


def resolve_chat_id(name):
    """按群名搜索兜底（群可能改名 / chat_id 失效时使用）。"""
    j = run(["lark-cli", "im", "+chat-search", "--query", name,
             "--format", "json", "--as", "user"])
    if not j.get("ok"):
        return None
    chats = j.get("data", {}).get("chats", [])
    for c in chats:
        if c.get("name") == name:
            return c.get("chat_id")
    return chats[0].get("chat_id") if chats else None


def clean(line):
    s = line.replace("**", "").replace("__", "").strip()
    s = re.sub(r"🖼️?[^\n]*?\((?:img_key|keys):[^)]*\)", "（图片）", s)
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()


def title_floors(title):
    """从卡片标题取楼层：【深圳湾】B7/32/47餐厅-午餐预告 -> ['B7','32F','47F']"""
    m = re.search(r"([A-Z0-9F/、，,]+?)\s*餐厅", title)
    if not m:
        return floors_of(title)
    out = []
    for tok in re.split(r"[/、,，]", m.group(1)):
        tok = tok.strip().upper()
        if not tok:
            continue
        if tok in ("B7", "A7"):
            out.append(tok)
        elif re.fullmatch(r"\d{1,2}F?", tok):
            out.append(tok if tok.endswith("F") else tok + "F")
    return out or floors_of(title)


def split_header(header):
    """拆出档口名与区域，用于排版：32F-B区「自选粉面」"""
    names = re.findall(r"[「【]([^」】]+)[」】]", header)
    venue = names[-1] if names else re.sub(r"^[^0-9A-Za-z\u4e00-\u9fff]+", "", header)
    venue = re.sub(r"(档口|餐线|菜单)$", lambda m: m.group(1), venue).strip()
    area = re.search(r"([ABC]区(?:[、/][ABC]区)*)", header)
    return venue, (area.group(1) if area else "")


def floors_of(text):
    """从标题/段落行提取楼层，返回规范化列表，如 ['32F', '47F']。"""
    found, seen = [], set()
    for m in FLOOR_RE.finditer(text):
        raw = m.group(1)
        f = raw if raw in ("B7", "A7") else raw + "F"
        if f not in seen:
            seen.add(f)
            found.append(f)
    return found


def classify(header):
    h = header
    if "自选" in h or "自助" in h or "轻食" in h:
        return "自选"
    if "套餐" in h or "盒饭" in h or "点餐柜" in h:
        return "套餐"
    return "特色档口"


def hits_in(text):
    out = []
    for canon, aliases in LIKES.items():
        if any(a in text for a in aliases):
            out.append(canon)
    return out


def parse_card(content, create_time, link, msg_id=""):
    """把一张 interactive 卡片解析为 {title, meta[], sections[]}。"""
    m = re.search(r'<card title="(.*?)"', content, re.S)
    title = (m.group(1) if m else "").replace("\\n", " ").strip()
    body = re.sub(r"^<card[^>]*>", "", content, flags=re.S)
    body = re.sub(r"</card>\s*$", "", body, flags=re.S).strip()
    tfloors = title_floors(title)

    meta, sections, cur = [], [], None
    for raw_line in body.split("\n"):
        if "http" in raw_line or "许愿" in raw_line or "指南" in raw_line:
            cur = None   # 许愿表单/餐饮指南之后跟的是 banner 图，不是菜单图
            continue
        keys = IMG_KEY_RE.findall(raw_line)
        if keys and cur is not None:
            for grp in keys:
                cur["img_keys"] += [k.strip() for k in grp.split(",") if k.strip()]
        line = clean(raw_line)
        if not line or line in ("---", "（图片）"):
            continue
        if line.startswith("["):  # 许愿 / 指南等链接行
            continue
        if HEADER_RE.search(line) and not META_RE.match(line):
            header = line.lstrip("*#✨❣💕🔸▪ ").strip()
            if any(k in line for k in SKIP_HEADERS):
                cur = None
                continue
            fl = floors_of(header) or tfloors
            cur = {
                "header": header,
                "floors": fl,
                "type": classify(header),
                "dishes": [],
                "img_keys": [],
                "ocr_dishes": [],
                "image_only": False,
                "card_title": title,
                "message_id": msg_id,
                "link": link,
            }
            sections.append(cur)
            continue
        if META_RE.match(line):
            meta.append(line)
            continue
        if any(w in line for w in NOISE_WORDS):
            continue
        if cur is None:
            continue
        if line == "（图片）":
            continue
        if DISH_LINE_RE.search(line) or len(line) <= 24:
            cur["dishes"].append(line.replace("（图片）", "").strip(" ／/"))

    for s in sections:
        s["dishes"] = [d for d in s["dishes"] if d]
        s["img_keys"] = [k for k in s["img_keys"] if k]
        s["image_only"] = not s["dishes"]
        s["hits"] = hits_in(s["header"] + " " + " ".join(s["dishes"]))
    return {"title": title, "time": create_time, "link": link,
            "message_id": msg_id, "meta": meta, "sections": sections}


def parse_queue(content, create_time, link):
    """解析「XX楼午餐开餐排队情况」卡片。

    真实形态：标题含楼层，正文是 `**档口名**` + 图片，排队长短只在图里，
    文本里**没有**可解析的排队等级。所以只能输出「哪些楼层/档口发了排队通知」，
    绝不能凭空编造「排队少 / 排长队」。
    """
    m = re.search(r'<card title="(.*?)"', content, re.S)
    title = (m.group(1) if m else "").replace("\\n", " ").strip()
    # 排队卡标题形如「36楼午餐开餐排队情况」/「B7餐厅午餐开餐排队情况」，
    # 通用 FLOOR_RE 的后置断言在「36楼午」这种连写下不命中，故单独匹配
    qm = re.search(r"(B7|A7|\d{1,2})\s*(?:F|楼|餐厅)", title)
    floors = ([qm.group(1) if qm.group(1) in ("B7", "A7") else qm.group(1) + "F"]
              if qm else floors_of(title))
    body = re.sub(r"^<card[^>]*>", "", content, flags=re.S)
    body = re.sub(r"</card>\s*$", "", body, flags=re.S)
    stalls = []
    for raw in body.split("\n"):
        line = clean(raw)
        line = re.sub(r"^\d+[.、]\s*", "", line).lstrip("#* ").strip()
        if not line or line in ("---", "（图片）") or line.startswith("["):
            continue
        if "（图片）" in line or "</card>" in line or any(w in line for w in NOISE_WORDS):
            continue
        if 2 <= len(line) <= 14:
            stalls.append(re.sub(r"档口$", "", line))
    return {"title": title, "time": create_time, "link": link,
            "floors": floors, "stalls": stalls, "queue_level": None}


def parse_soldout(content, create_time, link):
    """解析「售罄 / 套餐中断」提示卡片 —— 这类是纯文本，菜名可解析，是很好的催饭素材。"""
    m = re.search(r'<card title="(.*?)"', content, re.S)
    title = (m.group(1) if m else "").replace("\\n", " ").strip()
    body = clean(re.sub(r"^<card[^>]*>", "", content, flags=re.S).replace("\n", " "))
    gone = re.findall(r"[【\[]([^】\]]{2,20})[】\]]", body)
    still = []
    m2 = re.search(r"(?:现还有|现有)(.{0,80}?)(?:任选|正常供应|供应)", body)
    if m2:
        still = [x for x in re.findall(r"[【\[]?([^【】\[\]、，,]{2,20})[】\]]?", m2.group(1))
                 if x.strip()]
    still = [s.strip() for s in still][:3]
    # 「现还有」里的菜名也会被 【】 匹配到 gone，需剔除，否则会误报售罄
    gone = [g for g in gone if g not in still][:3]
    return {"title": title, "time": create_time, "link": link,
            "floors": floors_of(title), "sold_out": gone,
            "still_available": still}


def apply_rules(sections):
    """P0-P3：返回 (kept_32f, kept_other, lobster_sections, dropped_count)"""
    kept32, other, lobster, dropped = [], [], [], 0
    for s in sections:
        is32 = "32F" in s["floors"]
        if is32:
            kept32.append(s)                      # P0 整段保留
            continue
        if s["type"] == "自选":
            if any(k in (s["header"] + " ".join(s["dishes"])) for k in LOBSTER):
                s["lobster"] = True               # P2 命中小龙虾 → 保留 + 🦞
                lobster.append(s)
            else:
                dropped += 1                      # P2 默认丢弃
            continue
        other.append(s)                           # P1 保留，菜名最多 6 道
    return kept32, other, lobster, dropped


def mark(text):
    """P3：命中爱吃清单的菜名加高亮。"""
    for canon, aliases in LIKES.items():
        for a in aliases:
            if a in text:
                return text + f"  ❤️{canon}"
    return text


def label_of(s):
    venue, area = split_header(s["header"])
    floors = "/".join(s["floors"]) or "未识别楼层"
    if len(s["floors"]) == 1 and area:
        floors = f"{s['floors'][0]}-{area}"
    return f"{floors}「{venue}」"


def fmt_section(s, limit=None, prefix="· "):
    line = f"{prefix}{label_of(s)}"
    if s.get("lobster"):
        line += " 🦞"
    dishes = s["dishes"] or s.get("ocr_dishes") or []
    if not dishes:
        n = len(s.get("img_keys") or [])
        return line + ("（图片菜单，这张没认出来，已附原图）" if n
                       else "（图片菜单，已附原图）")
    shown = dishes if limit is None else dishes[:limit]
    body = "\n".join("    " + mark(d) for d in shown)
    if limit is not None and len(dishes) > limit:
        body += f"\n    …等 {len(dishes) - limit} 道（详见附图）"
    return line + "\n" + body


def build_1215(day, cards, kept32, other, lobster):
    d = f"{day.month}月{day.day}日（{WEEKDAY_CN[day.weekday()]}）"
    lines = [f"🍱 午餐雷达 · {d}", ""]
    lines.append("【32F · 全量】")
    if kept32:
        for s in kept32:
            lines.append(fmt_section(s, limit=None))
        meta = []
        for c in cards:
            if any(s["card_title"] == c["title"] for s in kept32):
                meta += c["meta"]
        seen = set()
        meta = [m for m in meta if not (m in seen or seen.add(m))]
        if meta:
            lines.append("  " + " ｜ ".join(meta[:3]))
    else:
        lines.append("  今天没抓到 32F 的预告段落")
    lines += ["", "【其他楼层 · 非自选】"]
    if other:
        for s in other:
            lines.append(fmt_section(s, limit=6))
    else:
        lines.append("  暂无")
    if lobster:
        lines += ["", "🦞 其他楼层自选命中小龙虾："]
        for s in lobster:
            lines.append(fmt_section(s, limit=6))
    all_hits = [(label_of(s), h) for s in kept32 + other + lobster
                for h in s.get("hits", [])]
    if all_hits:
        lines += ["", "❤️ 今天有你爱吃的："]
        for lb, h in all_hits:
            lines.append(f"  {lb} → {h}")
    return "\n".join(lines)


def build_1230(day, kept32, other, lobster, degraded=False, no_preview=False,
               queues=None, soldouts=None):
    """12:30 催饭话术：第一目标是催她去吃饭，所以开头一句必须是催，而不是菜单。"""
    queues, soldouts = queues or [], soldouts or []
    if no_preview:
        return ("🍽 12:30 啦，别写了，先去吃饭！\n"
                "今天群里还没发午餐预告，菜单我没抓到，直接下楼看看吧。\n"
                "⏰ 自助餐线 13:30 收档，再晚就只剩加时盒饭了（7F/32F/35F/47F）。")
    hits = [(label_of(s), h) for s in kept32 + other + lobster
            for h in s.get("hits", [])]
    lines = ["🍽 12:30 啦，别写了，先去吃饭！"]
    if hits:
        lb, h = hits[0]
        lines.append(f"❤️ {lb} 今天有你爱的 **{h}**，冲就完事了。")
        for lb2, h2 in hits[1:3]:
            lines.append(f"备选：{lb2} 有 {h2}")
    else:
        cands = [s for s in kept32 + other if not s["image_only"]][:2] or (kept32 + other)[:2]
        if cands:
            lines.append("今天文本里没看到你的爱吃清单，不过可以去：" +
                         "、".join(label_of(c) for c in cands))
        else:
            lines.append("菜单没解析出来，直接看群里原文吧。")
    for s in lobster:
        lines.append(f"🦞 {label_of(s)} 有小龙虾，值得专门跑一趟。")
    # 排队通知：只说「哪些楼层已开餐」，排队长短在图里，不编造等级
    if queues:
        fl = sorted({f for q in queues for f in q["floors"]})
        if fl:
            lines.append(f"🚶 {'/'.join(fl)} 都发了排队通知，说明已经开餐一会儿了，"
                         "这会儿去正好错峰。")
    # 售罄提示：最强的催饭理由
    for so in soldouts[:2]:
        if so["sold_out"]:
            tail = f"，还有 {'、'.join(so['still_available'])}" if so["still_available"] else ""
            lines.append(f"⚠️ {so['title']}：{so['sold_out'][0]} 已经售罄了{tail} —— 手慢真的会没。")
    if degraded:
        lines.append("（今天消息格式有变化，已降级为原文提醒）")
    lines.append("⏰ 自助餐线 13:30 收档，再晚下去就只剩汤和加时盒饭了，快去～")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=None, help="YYYY-MM-DD，默认今天")
    ap.add_argument("--chat-id", default=None)
    ap.add_argument("--ocr-json", default="",
                    help='OCR 结果文件：{"<label>": ["菜名", ...]}，合并进 ocr_dishes')
    ap.add_argument("--slot", default="12:15", choices=["12:15", "12:30"])
    ap.add_argument("--start", default="11:40", help="菜单时间窗起点 HH:MM")
    ap.add_argument("--end", default="12:10", help="菜单时间窗终点 HH:MM")
    ap.add_argument("--extra-end", default="13:00",
                    help="排队/售罄通知抓取终点 HH:MM（菜单窗之后的增量信息）")
    a = ap.parse_args()

    day = datetime.strptime(a.date, "%Y-%m-%d").date() if a.date else _date.today()
    chat_id = a.chat_id or os.environ.get("LUNCH_RADAR_CHAT_ID") or CHAT_ID_DEFAULT

    # 一次抓到 extra_end，菜单只认 11:40-12:10 窗内的卡片，排队/售罄用全窗
    def fetch(cid):
        return run(["lark-cli", "im", "+chat-messages-list", "--chat-id", cid,
                    "--start-time", f"{day.isoformat()} {a.start}:00",
                    "--end-time", f"{day.isoformat()} {a.extra_end}:59",
                    "--sort", "asc", "--page-size", "50",
                    "--format", "json", "--as", "user"])

    j = fetch(chat_id)
    if not j.get("ok"):
        alt = resolve_chat_id(CHAT_NAME)
        if not alt:
            print(json.dumps({"status": "chat_not_found", "chat_id_tried": chat_id,
                              "hint": f"按群名『{CHAT_NAME}』也没搜到，请向用户索要群链接",
                              "error": j.get("error")}, ensure_ascii=False, indent=2))
            return 2
        chat_id = alt
        j = fetch(chat_id)
        if not j.get("ok"):
            print(json.dumps({"status": "error", "error": j.get("error")},
                             ensure_ascii=False, indent=2))
            return 2

    msgs = j.get("data", {}).get("messages", [])

    def in_menu_window(m):
        t = (m.get("create_time") or "")[-5:]
        return a.start <= t <= a.end

    def already_sent(m):
        """排队/售罄通知只能用推送时刻之前已经发出的，否则等于穿越编造。"""
        return (m.get("create_time") or "")[-5:] <= a.slot

    cards_msgs, queue_msgs, soldout_msgs = [], [], []
    for m in msgs:
        c = m.get("content", "")
        if m.get("msg_type") != "interactive":
            continue
        if "排队情况" in c:
            if already_sent(m):
                queue_msgs.append(m)
        elif "售罄" in c or "中断" in c:
            if already_sent(m):
                soldout_msgs.append(m)
        elif "午餐预告" in c and in_menu_window(m):
            cards_msgs.append(m)
    raw_cards = cards_msgs

    queues = [parse_queue(m["content"], m.get("create_time", ""),
                          m.get("message_app_link", "")) for m in queue_msgs]
    soldouts = [parse_soldout(m["content"], m.get("create_time", ""),
                              m.get("message_app_link", "")) for m in soldout_msgs]

    if not raw_cards:
        res = {"status": "no_preview", "chat_id": chat_id, "date": day.isoformat(),
               "cards": [], "sections": [], "likes_hits": [], "lobster_hits": [],
               "links": [], "queue_notices": queues, "soldout_notices": soldouts,
               "message_text": build_1230(day, [], [], [], no_preview=True,
                                          queues=queues, soldouts=soldouts)
               if a.slot == "12:30" else ""}
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0

    cards = [parse_card(m["content"], m.get("create_time", ""),
                        m.get("message_app_link", ""), m.get("message_id", ""))
             for m in raw_cards]
    sections = [s for c in cards for s in c["sections"]]
    degraded = not sections or all(not s["floors"] for s in sections)

    if degraded:
        raw_text = "\n\n".join(
            f"【{c['title']}】\n" + "\n".join(c["meta"]) for c in cards)
        highlighted = raw_text
        for canon, aliases in LIKES.items():
            for al in aliases:
                highlighted = highlighted.replace(al, f"❤️{al}")
        text = (f"🍱 午餐雷达 · {day.month}月{day.day}日（格式有变，原文转发）\n\n{highlighted}"
                if a.slot == "12:15" else build_1230(day, [], [], [], degraded=True,
                                                     queues=queues, soldouts=soldouts))
        print(json.dumps({"status": "degraded", "chat_id": chat_id, "date": day.isoformat(),
                          "cards": cards, "sections": sections, "likes_hits": [],
                          "lobster_hits": [], "links": [c["link"] for c in cards],
                          "queue_notices": queues, "soldout_notices": soldouts,
                          "message_text": text}, ensure_ascii=False, indent=2))
        return 0

    kept32, other, lobster, dropped = apply_rules(sections)

    if a.ocr_json and os.path.exists(a.ocr_json):
        ocr = json.load(open(a.ocr_json, encoding="utf-8"))
        for s_ in sections:
            got = ocr.get(label_of(s_)) or ocr.get(s_["header"]) or []
            s_["ocr_dishes"] = [d for d in got if d]
            if s_["ocr_dishes"]:
                s_["hits"] = sorted(set(s_.get("hits", []))
                                    | set(hits_in(" ".join(s_["ocr_dishes"]))))

    image_tasks = [{"label": label_of(s_), "floors": s_["floors"],
                    "type": s_["type"], "message_id": s_["message_id"],
                    "img_keys": s_["img_keys"]}
                   for s_ in kept32 + other + lobster if s_["img_keys"]]
    likes = sorted({h for s in kept32 + other + lobster for h in s.get("hits", [])})
    text = (build_1215(day, cards, kept32, other, lobster) if a.slot == "12:15"
            else build_1230(day, kept32, other, lobster,
                            queues=queues, soldouts=soldouts))
    print(json.dumps({
        "status": "ok", "chat_id": chat_id, "date": day.isoformat(),
        "slot": a.slot, "dropped_self_serve": dropped,
        "cards": [{"title": c["title"], "time": c["time"], "link": c["link"],
                   "meta": c["meta"]} for c in cards],
        "sections": sections, "kept_32f": kept32, "kept_other": other,
        "lobster_hits": lobster, "likes_hits": likes,
        "image_tasks": image_tasks,
        "queue_notices": queues, "soldout_notices": soldouts,
        "message_text": text,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
