#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 fetch_lunch_preview.py 输出的 image_tasks 里的菜单图下载到本地，供 OCR + 转发给用户。

用法：
    python3 scripts/fetch_lunch_preview.py --slot 12:15 > /tmp/lr.json
    python3 scripts/download_menu_images.py --input /tmp/lr.json --outdir outputs/lunch-radar/img

输出 JSON：{"images": [{"label","floor","path","ocr_ready"}], "failed": [...]}

两个设计约束：
1. 下载用 `--as user`（bot 通常不在这个外部群里，bot 身份会 404）。
2. 多模态识图有单图体积上限（约 3.8MB），超限自动压成 `<name>_s.jpg`，
   并把 `ocr_path` 指向压缩版；转发给用户仍用原图 `path`，保证清晰度。
"""
import argparse
import json
import os
import re
import subprocess
import sys

MAX_OCR_BYTES = 3_500_000


def safe(name):
    return re.sub(r"[^\w\u4e00-\u9fff.-]+", "_", name).strip("_")[:60]


def shrink(path):
    """超过多模态体积上限时压缩，返回可用于 OCR 的路径（失败则返回 None）。"""
    if os.path.getsize(path) <= MAX_OCR_BYTES:
        return path
    try:
        from PIL import Image
    except ImportError:
        return None
    out = os.path.splitext(path)[0] + "_s.jpg"
    im = Image.open(path).convert("RGB")
    im.thumbnail((1600, 1600))
    im.save(out, quality=80)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="fetch_lunch_preview.py 的输出 JSON")
    ap.add_argument("--outdir", default="outputs/lunch-radar/img")
    ap.add_argument("--limit", type=int, default=24, help="最多下载几张，防止刷屏/超时")
    a = ap.parse_args()

    data = json.load(open(a.input, encoding="utf-8"))
    tasks = data.get("image_tasks") or []
    os.makedirs(a.outdir, exist_ok=True)

    images, failed, n = [], [], 0
    for t in tasks:
        for i, key in enumerate(t["img_keys"]):
            if n >= a.limit:
                break
            n += 1
            base = safe(t["label"]) + (f"_{i + 1}" if len(t["img_keys"]) > 1 else "")
            path = os.path.join(a.outdir, base + ".png")
            p = subprocess.run(
                ["lark-cli", "im", "+messages-resources-download",
                 "--message-id", t["message_id"], "--file-key", key,
                 "--type", "image", "--output", path,
                 "--as", "user", "--format", "json"],
                capture_output=True, text=True)
            if p.returncode != 0 or not os.path.exists(path):
                failed.append({"label": t["label"], "img_key": key,
                               "error": (p.stderr or p.stdout)[:200]})
                continue
            images.append({"label": t["label"],
                           "floors": t.get("floors", []),
                           "type": t.get("type", ""),
                           "path": path,
                           "ocr_path": shrink(path)})
    print(json.dumps({"images": images, "failed": failed},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
